package com.main.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.dao.InvoiceRepository;
import com.main.model.Invoice;



@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceServiceIntf {

	@Autowired
	InvoiceRepository repo;
	
	public void saveProduct(Invoice product) {
		repo.save(product);		
	}

	public List<Invoice> fetchData() {
		
		return repo.findAll();
	}

}
