package com.main.service;

import java.util.List;

import com.main.model.Invoice;



public interface InvoiceServiceIntf {

	void saveProduct(Invoice product);

	List<Invoice> fetchData();	
}
